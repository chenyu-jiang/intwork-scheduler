// Copyright 2019 Uber Technologies, Inc. All Rights Reserved.
// Modifications Chenyu Jiang
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// =============================================================================

#ifndef PROPOSED_CONTROL_MANAGER_H
#define PROPOSED_CONTROL_MANAGER_H

#include <iostream>
#include <queue>
#include <vector>
#include <thread>
#include "tensor_manager.h"
#include "common.h"

namespace proposed {
namespace common {

class TensorPackElement {
public:
  TensorPackElement();

  TensorPackElement(int32_t rank, int32_t layer_id, int32_t partition_id): 
    rank(rank), layer_id(layer_id), partition_id(partition_id) {}

  TensorPackElement(const TensorPackElement& other) {
    rank = other.rank;
    layer_id = other.layer_id;
    partition_id = other.partition_id;
  }

  std::string to_string() const {
    return "r: " + std::to_string(rank) + 
            ",l: " + std::to_string(layer_id) + 
            ", p: " + std::to_string(partition_id) + "; ";
  }

  int32_t rank;
  int32_t layer_id = 0;
  int32_t partition_id = 0;
};

class TensorPack {
public:
  struct compare_tp {
    bool operator()(const TensorPack& l, const TensorPack& r) {
      return l.priority < r.priority;
    }
  };

  TensorPack() {};

  TensorPack(const std::vector<std::vector<TensorPackElement>>& tensors, 
              int32_t priority):
              tensors_(tensors), num_workers_(tensors.size()), 
              priority(priority) {}

  bool IncrementReceivedCount();

  const std::vector<TensorPackElement> YieldTensorPackElements();

  std::string to_string() const;

  int32_t priority;

private:
  int32_t num_workers_ = 0;
  int32_t current_step_ = 0;
  int32_t count_finished_ = 0;
  std::vector<std::vector<TensorPackElement>> tensors_;
};

class PackExecutor {
public:
  PackExecutor(TensorManager& tensor_manager): 
                tensor_manager_(tensor_manager) {}

  Status SignalPushFinished();

  std::vector<Response> 
    ConstructResponse(const std::vector<TensorPackElement>& tensors) const;

  void Post(TensorPack pack);

  bool IsExecuting() const {return executing_;}

private:
  bool ExecutePackInQueue_();

  std::priority_queue<TensorPack, std::deque<TensorPack>, TensorPack::compare_tp> 
    tp_queue_;
  
  bool executing_ = false;
  TensorPack executing_tp_;
  TensorManager& tensor_manager_;
};

class Controller {
public:
  Controller(): pack_executor_(tensor_manager_) {}

  Controller(const Controller&) = delete;
  // Functions must be overridden by concrete controller
  virtual void Initialize() = 0;

  void LaunchBackGroundThread();

  int32_t get_rank() const {return rank_;};

  // Interface to bytecore

  void SignalLayerReady(int32_t layer_id);

  void SignalPartitionFinished(int32_t layer_id, int32_t partition_id);

  void RegisterTensor(Tensor t);

  void Finalize();

  void Log(const std::string str);

protected:
  // The main function called during each tick, includes the entire workflow
  // of the scheduler.
  //
  // The scheduler follows a master-worker paradigm. Rank zero acts
  // as the master (the "coordinator"), whereas all other ranks are simply
  // workers. Workers will communicate with coordinator to agree on what
  // tensors to be pushed. The communication performs as following:
  //
  //      a) The workers send Requests to the coordinator, indicating the 
  //      operations that they finished in the last tick. The coordinator
  //      receives the Requests from the workers
  //
  //      b) The coordinator processes the requests. If a layer is ready or
  //      a push op is finished on every worker, it sends a response to workers.
  //
  //      e) The workers listen for Response messages, processing each one by
  //      doing the required operation. 
  void RunLoopOnce_();

  void RunMainLoop_();

  std::thread bg_thread;

  bool inited_ = false;
  // For rank 0 to receive other ranks' ready tensors.
  virtual std::vector<Request> RecvRequests_() = 0;

  // For other ranks to send their ready tensors to rank 0
  virtual void SendRequests_(const RequestList& request_list) = 0;

  virtual std::vector<Response> RecvResponses_() = 0;

  virtual std::vector<Response> 
    SendResponses_(const std::vector<ResponseList>& response_list) = 0;

  void ConstructTensorPacks_();

  // Store the Request, and return whether the total count of
  // Requests for that tensor is now equal to the HOROVOD size (and thus we are
  // ready to reduce the tensor).
  bool IncrementTensorCount_(const Request& msg);

  // Only exists on coordinator node, processes each received requests and 
  // check if a layer is ready
  void ProcessRequests_(const std::vector<Request>& recvd_requests);

  // Exists on worker side, processes the responses received from coordinator.
  void ProcessResponses_(const std::vector<Response>& recvd_responses);

  int rank_ = 0;
  int world_size_ = 1;
  bool is_coordinator_ = false;

  TensorManager tensor_manager_;

  // The following only exists on the coordinator node (rank zero).
  // Maintains the ready count for each layer.
  std::unordered_map<int32_t, int32_t> ready_table_;

  std::unordered_map<int32_t, std::vector<TensorPack>> tp_table_;

  PackExecutor pack_executor_;

};

} // namespace common
} // namespace proposed

#endif // PROPOSED_CONTROL_MANAGER_H
